﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design.Serialization;
using System.Text;

namespace GenericSwapMethodInteger
{
    public class Box<T>
    {
        public List<T> Values { get; set; } = new List<T>();

        public Box(List<T> list)
        {
            this.Values = list;
        }

        public void Swap(int first, int second)
        {
            T index = this.Values[first];
            this.Values[first] = this.Values[second];
            this.Values[second] = index;
        }
    }
}
