﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace IteratorsAndComparators
{
    class BooksComparer : IComparer<Book>
    {
        public int Compare(Book x,  Book y)
        {
            //if (x.Year > y.Year) // ако обърнем знака (<) на (>) => сменяме реда на сортировката books.Sort() или OrderBy() в низходящ ред
            //{
            //    return 1;
            //}
            //if (x.Year < y.Year) // Можем да сортираме по имената на книгите (по пэрва буква) => (Name[0] == other.Name[0])
            //{
            //    return -1;
            //}
            //else
            //{
            //    return 0;
            //}
            return 0;

            // return x.Year.CompareTo(y.Year);     // краткия запис на горното
        }
    }
}
